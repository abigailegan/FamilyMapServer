

package RequestResult;

/**
 * /clear request body
 */
public class ClearRequest {
    /**
     * Constructor for /clear request body (ClearService)
     * @return ClearRequest object
     */
    public ClearRequest ClearRequest() { return this; }
}
